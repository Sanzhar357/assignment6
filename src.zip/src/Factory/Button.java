package Factory;

public interface Button {
    public void render(int a, int b);
    public void onClick(String f);
}

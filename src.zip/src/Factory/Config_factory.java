package Factory;

public enum Config_factory {
    Windows,
    Web
}

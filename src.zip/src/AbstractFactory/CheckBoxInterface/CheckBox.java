package AbstractFactory.CheckBoxInterface;

public interface CheckBox {
    public void print();
}

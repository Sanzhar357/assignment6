package AbstractFactory.ButtonInterface;

public interface Button {
    public void paint();
}

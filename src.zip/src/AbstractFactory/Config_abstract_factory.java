package AbstractFactory;

public enum Config_abstract_factory {
    Windows,
    Mac
}

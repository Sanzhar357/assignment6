package Builder;

public class Director {
	
	public void makeEngine(Builder builder) {
		builder.setEngine("engine"); // dwaw
		builder.setSeats(10); // dwada
	}
}

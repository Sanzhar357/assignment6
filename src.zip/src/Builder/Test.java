package Builder;

public class Test {
	public static void main(String[] args) {
		Director director = new Director(); // aldlwa
		Car car = new Car(); // dwas
		director.makeEngine(car); //d wawad
		Plane plane = new Plane(); // wdasa
		director.makeEngine(plane); // dwada
		System.out.println(car.getEngine()); // wadsa
		System.out.println(plane.getEngine()); // dwa
	}
}
